export type Role = 'admin' | 'reception' | 'engineer' | 'super_admin';

// ── SLA ───────────────────────────────────────────────────────────
export type { SLATier, SLAStatus, SLAStatusLevel } from '../lib/sla';

export type JobStatus = 'New' | 'Assigned' | 'In Progress' | 'Completed' | 'Delivered';

export type PartRequestStatus = 'Pending' | 'Approved' | 'Rejected' | 'AwaitingStock';

export interface User {
  id: string;
  name: string;
  email: string;
  role: Role;
  active: boolean;
  avatar?: string;
  joinedAt: string;
  branchId?: string;
}

export interface Customer {
  id: string;
  name: string;
  phone: string;
  address: string;
  email?: string;
  createdAt: string;
  branchId?: string;
}

export interface Device {
  id: string;
  customerId: string;
  type: string;
  brand: string;
  model: string;
  serialNumber?: string;
  branchId?: string;
}

export interface ChecklistItem {
  id: string;
  text: string;
  done: boolean;
}

export interface JobActivity {
  id: string;
  jobId: string;
  userId: string;
  action: string;
  details?: string;
  createdAt: string;
}

export interface JobPhoto {
  id: string;
  jobId: string;
  url: string;
  type: 'before' | 'after';
  createdAt: string;
}

export interface Job {
  id: string;
  invoiceNumber?: string | null;
  paymentMethod?: string | null;
  customerId: string;
  deviceId: string;
  assignedEngineerId: string | null;
  status: JobStatus;
  problemDescription: string;
  estimatedCost: number;
  actualCost?: number;
  /** Advance / deposit collected at job intake. Deducted from balance due. */
  advanceAmount?: number;
  repairNotes?: string;
  checklist?: ChecklistItem[];
  rating?: number;
  feedback?: string;
  linkedJobId?: string;
  activities?: JobActivity[];
  photos?: JobPhoto[];
  createdAt: string;
  updatedAt: string;
  completedAt?: string;
  branchId?: string;
}

/** Inventory availability at the time the part request was submitted */
export type InventoryAvailability = 'available' | 'low_stock' | 'out_of_stock' | 'not_found';

export interface PartRequest {
  id: string;
  jobId: string;
  engineerId: string;
  partName: string;
  quantity: number;
  reason: string;
  status: PartRequestStatus;
  unitCost?: number | null;
  createdAt: string;
  reviewedAt?: string;
  /** Inventory status at submission time — shown as alert to admin/reception */
  inventoryStatus?: InventoryAvailability;
  /** Available quantity in inventory at submission time */
  inventoryQuantity?: number;
  /** Min stock threshold at submission time */
  inventoryMinStock?: number;
  branchId?: string;
}

export interface InventoryItem {
  id: string;
  name: string;
  quantity: number;
  unitCost: number;
  category: string;
  minStock: number;
  branchId?: string;
}

export interface SaleItem {
  id: string;
  saleId: string;
  inventoryItemId: string;
  itemName: string;
  quantity: number;
  unitPrice: number;
  subtotal: number;
}

export interface Sale {
  id: string;
  saleNumber: string;
  customerId: string | null;
  companyName: string;
  contactName: string;
  phone: string;
  notes: string;
  totalAmount: number;
  createdById: string;
  paidAt: string | null;
  createdAt: string;
  updatedAt: string;
  items: SaleItem[];
  branchId?: string;
}

export interface Notification {
  id: string;
  userId: string;
  message: string;
  read: boolean;
  createdAt: string;
  jobId?: string;
  branchId?: string;
}

export interface DashboardStats {
  totalCompletedJobs: number;
  totalPendingJobs: number;
  totalEngineers: number;
  activeEngineers: number;
  pendingPartsCount: number;
  lowStockCount: number;
  totalRevenue: number;
}